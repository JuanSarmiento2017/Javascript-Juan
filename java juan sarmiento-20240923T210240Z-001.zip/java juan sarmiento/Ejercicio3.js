"Use strict";  //Es el modo estricto en java//

alert("Como estas?")
"use strict"                /* El uso estricto no esta activado*/
