
//Tarea//
let nombre = "Juan"         //declaramos la variable nombre y se va a llamar abad

alert (`Hola ${1}`);                   //mostrara una alerta diciendo hola y 1

alert (`Hola ${"mundo"}`);             //Mostrara una alerta diciendo hola mundo

alert (`Hola ${nombre}`);               //Mostrara una alerta diciendo hola y mostrando la variable nombre que es igual a Juan//