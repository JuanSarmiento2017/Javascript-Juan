alert("Hola");
alert("Mundo");         //Los alert estan separados por ;, y el . se usa cuando se termina una funcion//

alert(3 +
    1                   /* Java detecta que un salto de linea es un punto y coma, pero no en esta ocasion, ya que como termina en + java detecta que la funcion no ha sido finalizada*/
    + 2);
    