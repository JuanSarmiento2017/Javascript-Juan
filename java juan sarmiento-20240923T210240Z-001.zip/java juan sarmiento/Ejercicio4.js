//Trea 1//
let admin, name;       //Se asigna la variable
name = "Jhon";          //Decimos que la variable name tenga nombre de jhon//
admin = "name";         //Decimos que la variable admin muestre la variable name//

alert(admin);           //Decimos que la alert muestre la variable admin//
//Tarea 2//
let nuestroplaneta = "tierra";      //Asignamos la variable nuestro planeta y que sea igual a tierra//
let visitante = "juan";             //Asignamos la variable visitante y que sea igual a juan/


