//TAREA1//

let nombre = prompt("¿Cual es tu nombre?", "")      //Declaramos nombre como prompt, que prompt pide al usuario que digite un texto//
alert (nombre)      //Lo muestra como una alerta//