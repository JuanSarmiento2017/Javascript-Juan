
    let S =  prompt("Digita un numero 1-7", "")   

switch (S) { 

    case "1" : 
        alert  ("lunes")
        break;

    case "2":
        alert( 'martes' );
        break;
     
    case "3" :
        alert ("miercoles")
        break;

    case "4": 
        alert ("jueves")
        break;
      
    case "5":
        alert ("viernes")
        break;

    case "6": 
        alert ("sabado")
        break;

    case "7": 
        alert ("domingo")
        break;
 
         default:
        alert("No existe"); }

   